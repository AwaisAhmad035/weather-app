﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void OnShowButtonClicked(object sender, RoutedEventArgs e)
        {
            try
            {
                string uri = string.Format("http://api.weatherstack.com/current?access_key=603b1ea39e61db2856b5a7efbaf75914&query={0}&days=1", CityText.Text);

                using (HttpClient httpClient = new HttpClient())
                {
                    string responseText = httpClient.GetAsync(uri).Result.Content.ReadAsStringAsync().Result;
                    JObject responseObject = (JObject)JsonConvert.DeserializeObject(responseText);
                    CountryText.Text = responseObject["location"]["country"].Value<string>();
                    TemperatureText.Text = responseObject["current"]["temperature"].Value<string>();
                    WindSpeedText.Text = responseObject["current"]["wind_speed"].Value<string>();
                    HumidityText.Text = responseObject["current"]["humidity"].Value<string>();
                    DescriptionText.Text = responseObject["current"]["weather_descriptions"][0].Value<string>();
                    string imageUrl = responseObject["current"]["weather_icons"][0].Value<string>();
                    iconImage.Source = new BitmapImage(new Uri(imageUrl, UriKind.Absolute));
                }
            }
            catch
            {

            }
        }
    }
}
